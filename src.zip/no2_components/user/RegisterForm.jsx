import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

const initialState = {
    id: "", username: "", password: "", confirmPassword: ""
}

const RegisterForm = ({setUsers}) => {
    const [user, setUser] = useState(initialState);
    const navigate = useNavigate();
    const handleChange = (event) =>{
        const {name, value} = event.target;
        setUser(prev => (
            {...prev, [name]: value}
        ))
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        if(user.password !== user.confirmPassword) {
            alert("비밀번호 일치하지 않습니다.")
            return;
        }
        setUsers(prev => (
            [
                ...prev,
                 {
                    id: Date.now(),
                    username: user.username,
                    password: user.password 
                 }

            ]
        ))
        navigate("/login")

    }

  return (
    <div>
        <form onSubmit={handleSubmit}>
            <h2>회원등록</h2>
            <div>
                <input 
                    type="text"
                    name="username"
                    value={user.username}
                    onChange={handleChange}
                    placeholder='사용자 이름'
                />
            </div>
            <div>
                <input 
                    type="password"
                    name="password"
                    value={user.password}
                    onChange={handleChange}
                    placeholder='비밀번호'
                />
            </div>
            <div>
                <input 
                    type="password"
                    name="confirmPassword"
                    value={user.confirmPassword}
                    onChange={handleChange}
                    placeholder='비밀번호 확인'
                />
            </div>
            <button>등록</button>
        </form>
      
    </div>
  )
}

export default RegisterForm
